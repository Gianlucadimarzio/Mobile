(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["recetbyfilter-recetbyfilter-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/recetbyfilter/recetbyfilter.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/recetbyfilter/recetbyfilter.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"warning\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>{{namecat}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"!disableloader1\">\n    <img style=\"width: 100% !important;     height: 10px;  margin-left: auto !important; margin-right: auto !important;\" src=\"/assets/Ellipsis-1s-200px.gif\"/>\n  </div>\n  <div *ngIf=\"disableloader1\">\n  <div *ngFor=\"let meal of recet\">\n    <ion-card (click)=\"gorecet(meal.idMeal)\">\n      <img src=\"{{meal.strMealThumb}}\"/>\n      <ion-card-content>\n        <ion-card-title>\n          {{meal.strMeal}}\n          </ion-card-title>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/recetbyfilter/recetbyfilter-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/recetbyfilter/recetbyfilter-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: RecetbyfilterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecetbyfilterPageRoutingModule", function() { return RecetbyfilterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _recetbyfilter_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./recetbyfilter.page */ "./src/app/recetbyfilter/recetbyfilter.page.ts");




const routes = [
    {
        path: '',
        component: _recetbyfilter_page__WEBPACK_IMPORTED_MODULE_3__["RecetbyfilterPage"]
    }
];
let RecetbyfilterPageRoutingModule = class RecetbyfilterPageRoutingModule {
};
RecetbyfilterPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RecetbyfilterPageRoutingModule);



/***/ }),

/***/ "./src/app/recetbyfilter/recetbyfilter.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/recetbyfilter/recetbyfilter.module.ts ***!
  \*******************************************************/
/*! exports provided: RecetbyfilterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecetbyfilterPageModule", function() { return RecetbyfilterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _recetbyfilter_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./recetbyfilter-routing.module */ "./src/app/recetbyfilter/recetbyfilter-routing.module.ts");
/* harmony import */ var _recetbyfilter_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./recetbyfilter.page */ "./src/app/recetbyfilter/recetbyfilter.page.ts");







let RecetbyfilterPageModule = class RecetbyfilterPageModule {
};
RecetbyfilterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _recetbyfilter_routing_module__WEBPACK_IMPORTED_MODULE_5__["RecetbyfilterPageRoutingModule"]
        ],
        declarations: [_recetbyfilter_page__WEBPACK_IMPORTED_MODULE_6__["RecetbyfilterPage"]]
    })
], RecetbyfilterPageModule);



/***/ }),

/***/ "./src/app/recetbyfilter/recetbyfilter.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/recetbyfilter/recetbyfilter.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlY2V0YnlmaWx0ZXIvcmVjZXRieWZpbHRlci5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/recetbyfilter/recetbyfilter.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/recetbyfilter/recetbyfilter.page.ts ***!
  \*****************************************************/
/*! exports provided: RecetbyfilterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecetbyfilterPage", function() { return RecetbyfilterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _api_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../api-service.service */ "./src/app/api-service.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");





let RecetbyfilterPage = class RecetbyfilterPage {
    constructor(active, apiservice, navCtrl) {
        this.active = active;
        this.apiservice = apiservice;
        this.navCtrl = navCtrl;
        this.searchQuery = '';
        this.tab = [];
        this.tab2 = [];
        this.recet = [];
        this.meals = [];
        this.category = [];
        this.disableloader1 = false;
        this.disableloader2 = false;
    }
    ngOnInit() {
        let type = this.active.snapshot.paramMap.get("type");
        this.namecat = this.active.snapshot.paramMap.get("name");
        let name = this.active.snapshot.paramMap.get("name");
        this.category = this.apiservice.getAllfoodcategorie(name, type).subscribe(data => {
            this.tab = data;
            this.tab.meals.forEach(c => {
                this.recet.push(c);
            });
            this.disableloader1 = true;
        });
        //  alert(name);
    }
    //https://www.youtube.com/watch?v=oDt8z2lHAHg
    gorecet(id) {
        this.navCtrl.navigateForward("/singlerecet/" + id);
    }
};
RecetbyfilterPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _api_service_service__WEBPACK_IMPORTED_MODULE_3__["ApiServiceService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
];
RecetbyfilterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-recetbyfilter',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./recetbyfilter.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/recetbyfilter/recetbyfilter.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./recetbyfilter.page.scss */ "./src/app/recetbyfilter/recetbyfilter.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _api_service_service__WEBPACK_IMPORTED_MODULE_3__["ApiServiceService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
], RecetbyfilterPage);



/***/ })

}]);
//# sourceMappingURL=recetbyfilter-recetbyfilter-module-es2015.js.map