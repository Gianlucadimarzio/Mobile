(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tab1/tab1.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tab1/tab1.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n<ion-searchbar  color=\"warning\" [(ngModel)]=\"searchQuery\" (change)=\"search($event)\" autocorrect=\"off\"></ion-searchbar>\n<div class=\"title ion-padding\">\n  <h2 style=\"font-size: 15px;\">Categories</h2>\n</div>\n\n<div class=\"category-slider ion-padding-start\">\n  <div *ngIf=\"!disableloader1\">\n    <img style=\"width: 100% !important;     height: 10px;  margin-left: auto !important; margin-right: auto !important;\" src=\"/assets/Ellipsis-1s-200px.gif\"/>\n  </div>\n \n    <ion-slides *ngIf=\"disableloader1\" [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true,autoplay: {delay: 2000},initialSlide: 1 }\">\n      <ion-slide *ngFor=\"let cat of pat\">\n        <ion-col (click)=\"gopage(cat.strCategory,'cat')\">\n          <h4 style=\"color: black;\">{{ cat.strCategory }}</h4>\n          <img src=\"{{ cat.strCategoryThumb }}\" />\n          \n        </ion-col>\n      </ion-slide>\n    </ion-slides>\n</div>\n<div class=\"title ion-padding\">\n  <h2 style=\"font-size: 15px;\">Recipe of day </h2>\n</div>\n<div *ngIf=\"!disableloader2\">\n  <img style=\"width: 100% !important;     height: 10px;  margin-left: auto !important; margin-right: auto !important;\" src=\"/assets/Ellipsis-1s-200px.gif\"/>\n</div>\n<div *ngIf=\"disableloader2\">\n<div *ngFor=\"let meal of mealofday\">\n  <ion-card (click)=\"gorecet(meal.idMeal)\"> \n    <img src=\"{{meal.strMealThumb}}\"/>\n    <ion-card-content>\n      <ion-card-title>\n        {{meal.strMeal}}\n        </ion-card-title>\n    </ion-card-content>\n  </ion-card>\n</div>\n</div>\n<div class=\"title ion-padding\">\n  <h2 style=\"font-size: 15px;\">Browse Country</h2>\n</div>\n\n<div class=\"category-slider ion-padding-start\">\n<ion-slides [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true,autoplay: {delay: 2000},initialSlide: 1 }\">\n    <ion-slide (click)=\"gopage('British','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">British</h4>\n        <img src=\"/assets/pays/gb.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('American','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">American</h4>\n        <img src=\"/assets/pays/us.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('French','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">French</h4>\n        <img src=\"/assets/pays/fr.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide  (click)=\"gopage('Canadian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Canadian</h4>\n        <img src=\"/assets/pays/ca.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Jamaican','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Jamaican</h4>\n        <img src=\"/assets/pays/jm.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Chinese','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Chinese</h4>\n        <img src=\"/assets/pays/cn.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Dutch','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Dutch</h4>\n        <img src=\"/assets/pays/nl.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Egyptian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Egyptian</h4>\n        <img src=\"/assets/pays/eg.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Greek','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Greek</h4>\n        <img src=\"/assets/pays/gr.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide  (click)=\"gopage('Indian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Indian</h4>\n        <img src=\"/assets/pays/in.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Irish','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Irish</h4>\n        <img src=\"/assets/pays/ie.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Italian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Italian</h4>\n        <img src=\"/assets/pays/it.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Japanese','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Japanese</h4>\n        <img src=\"/assets/pays/jp.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Kenyan','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Kenyan</h4>\n        <img src=\"/assets/pays/kn.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n\n    <ion-slide (click)=\"gopage('Malaysian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Malaysian</h4>\n        <img src=\"/assets/pays/my.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n\n    <ion-slide (click)=\"gopage('Mexican','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Mexican</h4>\n        <img src=\"/assets/pays/mx.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Moroccan','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Moroccan</h4>\n        <img src=\"/assets/pays/ma.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Croatian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Croatian</h4>\n        <img src=\"/assets/pays/hr.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Norwegian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\">Norwegian</h4>\n        <img src=\"/assets/pays/no.png\" />\n      </ion-col>\n    </ion-slide>\n\n   \n    <ion-slide (click)=\"gopage('Croatian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Croatian</h4>\n        <img src=\"/assets/pays/hr.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    \n\n    <ion-slide (click)=\"gopage('Portuguese','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Portuguese</h4>\n        <img src=\"/assets/pays/pt.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Russian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Russian</h4>\n        <img src=\"/assets/pays/ru.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n\n    <ion-slide (click)=\"gopage('Argentinian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Argentinian</h4>\n        <img src=\"/assets/pays/ar.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Spanish','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Spanish</h4>\n        <img src=\"/assets/pays/eERs.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n    <ion-slide (click)=\"gopage('Slovakian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Slovakian</h4>\n        <img src=\"/assets/pays/sk.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n\n    <ion-slide (click)=\"gopage('Slovakian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Slovakian</h4>\n        <img src=\"/assets/pays/sk.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Thai','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Thai</h4>\n        <img src=\"/assets/pays/th.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Saudi Arabian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Saudi Arabian</h4>\n        <img src=\"/assets/pays/sa.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Vietnamese','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Vietnamese</h4>\n        <img src=\"/assets/pays/vn.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Turkish','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Turkish</h4>\n        <img src=\"/assets/pays/tSr.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Syrian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Syrian</h4>\n        <img src=\"/assets/pays/sy.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Algerian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Algerian</h4>\n        <img src=\"/assets/pays/dz.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Tunisian','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Tunisian</h4>\n        <img src=\"/assets/pays/tn.png\" />\n      </ion-col>\n    </ion-slide>\n\n    <ion-slide (click)=\"gopage('Polish','pay')\">\n      <ion-col>\n        <h4 style=\"color: black;\" >Polish</h4>\n        <img src=\"/assets/pays/pl.png\" />\n      </ion-col>\n    </ion-slide>\n\n\n \n\n  </ion-slides>\n</div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/tab1/tab1-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/*! exports provided: Tab1PageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageRoutingModule", function() { return Tab1PageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_3__["Tab1Page"],
    }
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ "./src/app/tab1/tab1.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../explore-container/explore-container.module */ "./src/app/explore-container/explore-container.module.ts");
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./tab1-routing.module */ "./src/app/tab1/tab1-routing.module.ts");








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_6__["ExploreContainerComponentModule"],
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_7__["Tab1PageRoutingModule"]
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_5__["Tab1Page"]]
    })
], Tab1PageModule);



/***/ }),

/***/ "./src/app/tab1/tab1.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-menu-button {\n  margin-left: 10px;\n}\n\n.filter {\n  margin-right: 10px;\n}\n\n.search {\n  margin-bottom: 20px;\n}\n\n.search ion-item {\n  border-radius: 10px;\n  box-shadow: 0px 13px 30px 0px rgba(0, 0, 0, 0.09);\n  padding: 8px;\n}\n\n.search ion-item ion-icon {\n  margin-right: 16px;\n}\n\n.search ion-item ion-input {\n  padding-left: 10px !important;\n  border-left: 1px solid #F4F4F4;\n}\n\n.title {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n          align-items: center;\n  padding-bottom: 32px;\n}\n\n.title h2 {\n  margin: 0 0 0 16px;\n  color: #434343;\n}\n\n.title p {\n  margin: 0 16px 0 0;\n  color: #656565;\n}\n\n.category-slider ion-slide {\n  width: 150px;\n  height: 100px;\n  margin-right: 10px;\n  margin-left: 20px;\n  margin-bottom: 30px;\n}\n\n.category-slider ion-slide ion-col {\n  height: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n}\n\n.category-slider ion-slide ion-col h4 {\n  color: #ffffff;\n  margin: 0;\n}\n\n.category-slider ion-slide ion-col img {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 8px;\n  top: 0;\n  left: 0;\n  z-index: -1;\n  box-shadow: 0px 15px 20px 0px rgba(0, 0, 0, 0.16);\n}\n\n.font-bold {\n  font-weight: bold;\n}\n\n.product-slider {\n  margin-bottom: 30px;\n}\n\n.product-slider ion-slide {\n  width: 150px;\n  height: auto;\n  margin-left: 20px;\n  margin-right: 10px;\n}\n\n.product-slider ion-slide ion-col img {\n  width: 100%;\n  height: 180px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 8px;\n}\n\n.product-slider ion-slide ion-col p {\n  margin-top: 5px;\n  margin-bottom: 0;\n}\n\n.product-slider ion-slide ion-col h6 {\n  margin-top: 5px;\n  margin-bottom: 0;\n}\n\nion-slide:focus {\n  outline: none !important;\n}\n\nion-col:focus {\n  outline: none !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMS9DOlxccHJvamV0IGFuZHJvaWRcXGZvb2RhcHBsaWNhdGlvblxcZm9vZGFwcC9zcmNcXGFwcFxcdGFiMVxcdGFiMS5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYjEvdGFiMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7QUNDSjs7QURFQTtFQUNJLG1CQUFBO0FDQ0o7O0FEQ0k7RUFDSSxtQkFBQTtFQUNBLGlEQUFBO0VBQ0EsWUFBQTtBQ0NSOztBRENRO0VBQ0ksa0JBQUE7QUNDWjs7QURFUTtFQUNJLDZCQUFBO0VBQ0EsOEJBQUE7QUNBWjs7QURLQTtFQUNJLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHlCQUFBO1VBQUEsOEJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0VBQ0Esb0JBQUE7QUNGSjs7QURJSTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQ0ZSOztBREtJO0VBQ0ksa0JBQUE7RUFDQSxjQUFBO0FDSFI7O0FEUUk7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQ0xSOztBRE9RO0VBQ0ksWUFBQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDTFo7O0FET1k7RUFDSSxjQUFBO0VBQ0EsU0FBQTtBQ0xoQjs7QURRWTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxpREFBQTtBQ05oQjs7QURZQTtFQUNJLGlCQUFBO0FDVEo7O0FEWUE7RUFDSSxtQkFBQTtBQ1RKOztBRFdJO0VBQ0ksWUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDVFI7O0FEWVk7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxrQkFBQTtBQ1ZoQjs7QURhWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQ1hoQjs7QURjWTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQ1poQjs7QURtQkE7RUFDSSx3QkFBQTtBQ2hCSjs7QURtQkE7RUFDSSx3QkFBQTtBQ2hCSiIsImZpbGUiOiJzcmMvYXBwL3RhYjEvdGFiMS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudS1idXR0b24ge1xuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4uZmlsdGVyIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5zZWFyY2gge1xuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG5cbiAgICBpb24taXRlbSB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgIGJveC1zaGFkb3c6IDBweCAxM3B4IDMwcHggMHB4IHJnYmEoMCwgMCwgMCwgMC4wOSk7XG4gICAgICAgIHBhZGRpbmc6IDhweDtcblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG4gICAgICAgIH1cblxuICAgICAgICBpb24taW5wdXQge1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNGNEY0RjQ7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi50aXRsZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBwYWRkaW5nLWJvdHRvbTogMzJweDtcblxuICAgIGgyIHtcbiAgICAgICAgbWFyZ2luOiAwIDAgMCAxNnB4O1xuICAgICAgICBjb2xvcjogIzQzNDM0MztcbiAgICB9XG5cbiAgICBwIHtcbiAgICAgICAgbWFyZ2luOiAwIDE2cHggMCAwO1xuICAgICAgICBjb2xvcjogIzY1NjU2NTtcbiAgICB9XG59XG5cbi5jYXRlZ29yeS1zbGlkZXIge1xuICAgIGlvbi1zbGlkZSB7XG4gICAgICAgIHdpZHRoOiAxNTBweDtcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICBtYXJnaW4tbGVmdDogMjBweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMzBweDtcblxuICAgICAgICBpb24tY29sIHtcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgICAgIGg0IHtcbiAgICAgICAgICAgICAgICBjb2xvcjogI2ZmZmZmZjtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgICAgIGxlZnQ6IDA7XG4gICAgICAgICAgICAgICAgei1pbmRleDogLTE7XG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDE1cHggMjBweCAwcHggcmdiYSgwLCAwLCAwLCAwLjE2KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmZvbnQtYm9sZCB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5wcm9kdWN0LXNsaWRlciB7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcblxuICAgIGlvbi1zbGlkZSB7XG4gICAgICAgIHdpZHRoOiAxNTBweDtcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICBtYXJnaW4tbGVmdDogMjBweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuXG4gICAgICAgIGlvbi1jb2wge1xuICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE4MHB4O1xuICAgICAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcCB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGg2IHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gUmVtb3ZpbmcgaGlnaGxpZ2h0IHdoZW4gZm9jdXNlZC9jbGlja2VkIG9uIHByb2R1Y3Rcbmlvbi1zbGlkZTpmb2N1cyB7XG4gICAgb3V0bGluZTogbm9uZSAhaW1wb3J0YW50O1xufVxuXG5pb24tY29sOmZvY3VzIHtcbiAgICBvdXRsaW5lOiBub25lICFpbXBvcnRhbnQ7XG59IiwiaW9uLW1lbnUtYnV0dG9uIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5maWx0ZXIge1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5zZWFyY2gge1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuLnNlYXJjaCBpb24taXRlbSB7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJveC1zaGFkb3c6IDBweCAxM3B4IDMwcHggMHB4IHJnYmEoMCwgMCwgMCwgMC4wOSk7XG4gIHBhZGRpbmc6IDhweDtcbn1cbi5zZWFyY2ggaW9uLWl0ZW0gaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG59XG4uc2VhcmNoIGlvbi1pdGVtIGlvbi1pbnB1dCB7XG4gIHBhZGRpbmctbGVmdDogMTBweCAhaW1wb3J0YW50O1xuICBib3JkZXItbGVmdDogMXB4IHNvbGlkICNGNEY0RjQ7XG59XG5cbi50aXRsZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZy1ib3R0b206IDMycHg7XG59XG4udGl0bGUgaDIge1xuICBtYXJnaW46IDAgMCAwIDE2cHg7XG4gIGNvbG9yOiAjNDM0MzQzO1xufVxuLnRpdGxlIHAge1xuICBtYXJnaW46IDAgMTZweCAwIDA7XG4gIGNvbG9yOiAjNjU2NTY1O1xufVxuXG4uY2F0ZWdvcnktc2xpZGVyIGlvbi1zbGlkZSB7XG4gIHdpZHRoOiAxNTBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBtYXJnaW4tbGVmdDogMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbn1cbi5jYXRlZ29yeS1zbGlkZXIgaW9uLXNsaWRlIGlvbi1jb2wge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmNhdGVnb3J5LXNsaWRlciBpb24tc2xpZGUgaW9uLWNvbCBoNCB7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBtYXJnaW46IDA7XG59XG4uY2F0ZWdvcnktc2xpZGVyIGlvbi1zbGlkZSBpb24tY29sIGltZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB6LWluZGV4OiAtMTtcbiAgYm94LXNoYWRvdzogMHB4IDE1cHggMjBweCAwcHggcmdiYSgwLCAwLCAwLCAwLjE2KTtcbn1cblxuLmZvbnQtYm9sZCB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ucHJvZHVjdC1zbGlkZXIge1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xufVxuLnByb2R1Y3Qtc2xpZGVyIGlvbi1zbGlkZSB7XG4gIHdpZHRoOiAxNTBweDtcbiAgaGVpZ2h0OiBhdXRvO1xuICBtYXJnaW4tbGVmdDogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLnByb2R1Y3Qtc2xpZGVyIGlvbi1zbGlkZSBpb24tY29sIGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE4MHB4O1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xufVxuLnByb2R1Y3Qtc2xpZGVyIGlvbi1zbGlkZSBpb24tY29sIHAge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG4ucHJvZHVjdC1zbGlkZXIgaW9uLXNsaWRlIGlvbi1jb2wgaDYge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG5cbmlvbi1zbGlkZTpmb2N1cyB7XG4gIG91dGxpbmU6IG5vbmUgIWltcG9ydGFudDtcbn1cblxuaW9uLWNvbDpmb2N1cyB7XG4gIG91dGxpbmU6IG5vbmUgIWltcG9ydGFudDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/tab1/tab1.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _api_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../api-service.service */ "./src/app/api-service.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");





let Tab1Page = class Tab1Page {
    constructor(apiservice, navCtrl, loadingController) {
        this.apiservice = apiservice;
        this.navCtrl = navCtrl;
        this.loadingController = loadingController;
        // slideOptions = {
        //   initialSlide: 1,
        //   speed: 400,
        // };
        // slideOpts = {
        //   autoplay: {
        //   delay: 2000
        //   }
        //   };
        this.searchQuery = '';
        this.tab = [];
        this.tab2 = [];
        this.pat = [];
        this.mealofday = [];
        this.category = [];
        this.disableloader1 = false;
        this.disableloader2 = false;
    }
    ngOnInit() {
        this.initdate();
    }
    gorecet(id) {
        this.navCtrl.navigateForward("/singlerecet/" + id);
    }
    show() {
        this.loadingController.create({
            message: "please wait..."
        }).then(loeading => {
            loeading.present();
        });
    }
    initdate() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({ message: 'please wait...' });
            loading.present();
            yield this.getallcategories();
            loading.dismiss();
        });
    }
    search(event) {
        this.navCtrl.navigateForward("/result/" + this.searchQuery);
        ////////
        // this.category=this.apiservice.getrecherche(this.searchQuery).subscribe(data=>{
        //   this.tab=data;
        //     this.tab.categories.forEach(c=>{
        //       this.pat.push(c);
        //     });
        // })
        //alert(this.searchQuery);
    }
    getallcategories() {
        this.category = this.apiservice.getrecetofday().subscribe(data => {
            this.tab2 = data;
            this.tab2.meals.forEach(c => {
                this.mealofday.push(c);
            });
            // console.log("meri beaucoup");
            console.log(this.mealofday);
            this.disableloader1 = true;
            this.disableloader2 = true;
        });
        this.category = this.apiservice.getAllCategorie().subscribe(data => {
            this.tab = data;
            this.tab.categories.forEach(c => {
                this.pat.push(c);
            });
        });
    }
    gopage(name, type) {
        this.navCtrl.navigateForward("/recetbyfilter/" + name + "/" + type);
        // alert(name);
    }
};
Tab1Page.ctorParameters = () => [
    { type: _api_service_service__WEBPACK_IMPORTED_MODULE_1__["ApiServiceService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] }
];
Tab1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-tab1',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tab1.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tab1/tab1.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tab1.page.scss */ "./src/app/tab1/tab1.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_api_service_service__WEBPACK_IMPORTED_MODULE_1__["ApiServiceService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])
], Tab1Page);



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module-es2015.js.map