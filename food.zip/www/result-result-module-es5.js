function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["result-result-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/result/result.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/result/result.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppResultResultPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"warning\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Search results</ion-title>\n    <ion-title></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div *ngIf=\"testreturn\">\n  <div *ngFor=\"let meal of pat\">\n    <ion-card (click)=\"gorecet(meal.idMeal)\">\n      <img src=\"{{meal.strMealThumb}}\"/>\n      <ion-card-content>\n        <ion-card-title>\n          {{meal.strMeal}}\n          </ion-card-title>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</div>\n\n<div *ngIf=\"!testreturn\">\n  <div *ngIf=\"!endrchrche\">\n    \n\n      <img style=\"width: 100% !important;   margin-left: auto !important; margin-right: auto !important;\" src=\"/assets/Magnify-1s-200px.gif\"/>\n\n  </div>\n  <div *ngIf=\"endrchrche\">\n    <img src=\"/assets/8836650a57e0c941b4ccdc8a19dee887.png\"/>\n\n  </div>\n  \n      \n</div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/result/result-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/result/result-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: ResultPageRoutingModule */

  /***/
  function srcAppResultResultRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ResultPageRoutingModule", function () {
      return ResultPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _result_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./result.page */
    "./src/app/result/result.page.ts");

    var routes = [{
      path: '',
      component: _result_page__WEBPACK_IMPORTED_MODULE_3__["ResultPage"]
    }];

    var ResultPageRoutingModule = function ResultPageRoutingModule() {
      _classCallCheck(this, ResultPageRoutingModule);
    };

    ResultPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ResultPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/result/result.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/result/result.module.ts ***!
    \*****************************************/

  /*! exports provided: ResultPageModule */

  /***/
  function srcAppResultResultModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ResultPageModule", function () {
      return ResultPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _result_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./result-routing.module */
    "./src/app/result/result-routing.module.ts");
    /* harmony import */


    var _result_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./result.page */
    "./src/app/result/result.page.ts");

    var ResultPageModule = function ResultPageModule() {
      _classCallCheck(this, ResultPageModule);
    };

    ResultPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _result_routing_module__WEBPACK_IMPORTED_MODULE_5__["ResultPageRoutingModule"]],
      declarations: [_result_page__WEBPACK_IMPORTED_MODULE_6__["ResultPage"]]
    })], ResultPageModule);
    /***/
  },

  /***/
  "./src/app/result/result.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/result/result.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppResultResultPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Jlc3VsdC9yZXN1bHQucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/result/result.page.ts":
  /*!***************************************!*\
    !*** ./src/app/result/result.page.ts ***!
    \***************************************/

  /*! exports provided: ResultPage */

  /***/
  function srcAppResultResultPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ResultPage", function () {
      return ResultPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _api_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../api-service.service */
    "./src/app/api-service.service.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var ResultPage = /*#__PURE__*/function () {
      function ResultPage(active, apiservice, navCtrl, loadingController) {
        _classCallCheck(this, ResultPage);

        this.active = active;
        this.apiservice = apiservice;
        this.navCtrl = navCtrl;
        this.loadingController = loadingController;
        this.searchQuery = '';
        this.tab = [];
        this.tab2 = [];
        this.testreturn = false;
        this.endrchrche = false;
        this.pat = [];
        this.mealofday = [];
        this.category = [];
      }

      _createClass(ResultPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          alert(this.active.snapshot.paramMap.get("text"));
          this.category = this.apiservice.getrecherche(this.active.snapshot.paramMap.get("text")).subscribe(function (data) {
            _this.tab = data;
            alert(_this.tab.meals);

            if (_this.tab.meals) {
              _this.testreturn = true;

              _this.tab.meals.forEach(function (c) {
                _this.pat.push(c);
              });

              _this.endrchrche = true;
            } else {
              _this.testreturn = false;
              _this.endrchrche = true;
            }
          });
          alert(this.testreturn);
          console.log(this.pat);
        }
      }, {
        key: "gorecet",
        value: function gorecet(id) {
          this.navCtrl.navigateForward("/singlerecet/" + id);
        }
      }]);

      return ResultPage;
    }();

    ResultPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
      }, {
        type: _api_service_service__WEBPACK_IMPORTED_MODULE_1__["ApiServiceService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }];
    };

    ResultPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-result',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./result.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/result/result.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./result.page.scss */
      "./src/app/result/result.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _api_service_service__WEBPACK_IMPORTED_MODULE_1__["ApiServiceService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])], ResultPage);
    /***/
  }
}]);
//# sourceMappingURL=result-result-module-es5.js.map