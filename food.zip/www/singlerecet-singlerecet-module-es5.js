function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["singlerecet-singlerecet-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/singlerecet/singlerecet.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/singlerecet/singlerecet.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSinglerecetSinglerecetPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"warning\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>procedure</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"!disableloader1\">\n    <img style=\"width: 100% !important;     height: 10px;  margin-left: auto !important; margin-right: auto !important;\" src=\"/assets/Ellipsis-1s-200px.gif\"/>\n  </div>\n  <div *ngIf=\"disableloader1\">\n  <div *ngFor=\"let meal of recet\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>{{meal.strMeal}}</ion-card-title>\n      </ion-card-header>\n      <img src=\"{{meal.strMealThumb}}\"/>\n      <ion-card-content>\n        {{meal.strInstructions}}\n        \n<iframe width=\"100%\" height=\"315\"\n[src]=\"meal.strYoutube\">\n</iframe>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/singlerecet/singlerecet-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/singlerecet/singlerecet-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: SinglerecetPageRoutingModule */

  /***/
  function srcAppSinglerecetSinglerecetRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SinglerecetPageRoutingModule", function () {
      return SinglerecetPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _singlerecet_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./singlerecet.page */
    "./src/app/singlerecet/singlerecet.page.ts");

    var routes = [{
      path: '',
      component: _singlerecet_page__WEBPACK_IMPORTED_MODULE_3__["SinglerecetPage"]
    }];

    var SinglerecetPageRoutingModule = function SinglerecetPageRoutingModule() {
      _classCallCheck(this, SinglerecetPageRoutingModule);
    };

    SinglerecetPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SinglerecetPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/singlerecet/singlerecet.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/singlerecet/singlerecet.module.ts ***!
    \***************************************************/

  /*! exports provided: SinglerecetPageModule */

  /***/
  function srcAppSinglerecetSinglerecetModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SinglerecetPageModule", function () {
      return SinglerecetPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _singlerecet_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./singlerecet-routing.module */
    "./src/app/singlerecet/singlerecet-routing.module.ts");
    /* harmony import */


    var _singlerecet_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./singlerecet.page */
    "./src/app/singlerecet/singlerecet.page.ts");

    var SinglerecetPageModule = function SinglerecetPageModule() {
      _classCallCheck(this, SinglerecetPageModule);
    };

    SinglerecetPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _singlerecet_routing_module__WEBPACK_IMPORTED_MODULE_5__["SinglerecetPageRoutingModule"]],
      declarations: [_singlerecet_page__WEBPACK_IMPORTED_MODULE_6__["SinglerecetPage"]]
    })], SinglerecetPageModule);
    /***/
  },

  /***/
  "./src/app/singlerecet/singlerecet.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/singlerecet/singlerecet.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSinglerecetSinglerecetPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NpbmdsZXJlY2V0L3NpbmdsZXJlY2V0LnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/singlerecet/singlerecet.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/singlerecet/singlerecet.page.ts ***!
    \*************************************************/

  /*! exports provided: SinglerecetPage */

  /***/
  function srcAppSinglerecetSinglerecetPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SinglerecetPage", function () {
      return SinglerecetPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _api_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../api-service.service */
    "./src/app/api-service.service.ts");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");

    var SinglerecetPage = /*#__PURE__*/function () {
      function SinglerecetPage(active, apiservice, sanitizer) {
        _classCallCheck(this, SinglerecetPage);

        this.active = active;
        this.apiservice = apiservice;
        this.sanitizer = sanitizer;
        this.searchQuery = '';
        this.tab = [];
        this.tab2 = [];
        this.recet = [];
        this.meals = [];
        this.category = [];
        this.disableloader1 = false;
        this.disableloader2 = false;
      }

      _createClass(SinglerecetPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          console.log(this.getvideolink("https://www.youtube.com/watch?v=1L1wTXi281k"));
          alert(this.getvideolink("https://www.youtube.com/watch?v=1L1wTXi281k"));
          var id = this.active.snapshot.paramMap.get("id");
          this.category = this.apiservice.getrecet(id).subscribe(function (data) {
            _this.tab = data;

            _this.tab.meals.forEach(function (c) {
              c['strYoutube'] = _this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/' + _this.getvideolink(c['strYoutube']));

              _this.recet.push(c);
            });

            _this.disableloader1 = true;
          });
        }
      }, {
        key: "getvideolink",
        value: function getvideolink(url) {
          var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
          var match = url.match(regExp);
          return match && match[2].length === 11 ? match[2] : null;
        }
      }]);

      return SinglerecetPage;
    }();

    SinglerecetPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _api_service_service__WEBPACK_IMPORTED_MODULE_3__["ApiServiceService"]
      }, {
        type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"]
      }];
    };

    SinglerecetPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-singlerecet',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./singlerecet.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/singlerecet/singlerecet.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./singlerecet.page.scss */
      "./src/app/singlerecet/singlerecet.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _api_service_service__WEBPACK_IMPORTED_MODULE_3__["ApiServiceService"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"]])], SinglerecetPage);
    /***/
  }
}]);
//# sourceMappingURL=singlerecet-singlerecet-module-es5.js.map