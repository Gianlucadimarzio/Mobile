import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  constructor(private http:HttpClient) { }

  getAllCategorie(){
    let url="https://www.themealdb.com/api/json/v1/1/categories.php";
    return this.http.get(url);
  }

  getrecherche(text){
    let url="https://www.themealdb.com/api/json/v1/1/search.php?s="+text;
    return this.http.get(url);
  }


  getrecetofday(){
    let url="https://www.themealdb.com/api/json/v1/1/random.php";
    return this.http.get(url);
  }

  getrecet(id){
    let url="https://www.themealdb.com/api/json/v1/1/lookup.php?i="+id;
    return this.http.get(url);
  }

  getAllfoodcategorie(name,type){
    if(type==='cat'){
      let url="https://www.themealdb.com/api/json/v1/1/filter.php?c="+name;
    return this.http.get(url);
    }else{
      let url="https://www.themealdb.com/api/json/v1/1/filter.php?a="+name;
    return this.http.get(url);
    }
    
  }
}
