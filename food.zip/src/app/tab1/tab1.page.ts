import { ApiServiceService } from './../api-service.service';
import { Component,OnInit } from '@angular/core';
import { IonSlides,NavController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page implements OnInit{
  // slideOptions = {
  //   initialSlide: 1,
  //   speed: 400,
  // };

  // slideOpts = {
  //   autoplay: {
  //   delay: 2000
  //   }
  //   };
  
  searchQuery: string = '';
  items: string[];
  tab:any=[];
  tab2:any=[];
  public pat: any=[];
  public mealofday: any=[];
  public category:any=[];
  disableloader1:boolean=false;
  disableloader2:boolean=false;
  
  constructor(private apiservice:ApiServiceService,private navCtrl:NavController,private loadingController: LoadingController) {
    
  }
  

  ngOnInit() {
    this.initdate();
  }



  gorecet(id){
    this.navCtrl.navigateForward("/singlerecet/"+id);
  }


  
  show(){
    this.loadingController.create({
      message:"please wait..."
    }).then(loeading=>{
      loeading.present();
    })
  }

  async initdate(){

    const loading = await this.loadingController.create({message: 'please wait...'});
    loading.present();
    await this.getallcategories();
    loading.dismiss();
  }

  search(event){
    this.navCtrl.navigateForward("/result/"+this.searchQuery);
    ////////
    // this.category=this.apiservice.getrecherche(this.searchQuery).subscribe(data=>{
    //   this.tab=data;
    //     this.tab.categories.forEach(c=>{
    //       this.pat.push(c);
    //     });
    // })
    //alert(this.searchQuery);
  }
  getallcategories(){
    this.category=this.apiservice.getrecetofday().subscribe(data=>{
      this.tab2=data;
        this.tab2.meals.forEach(c=>{
          this.mealofday.push(c);
        });
       // console.log("meri beaucoup");
        console.log(this.mealofday);
        this.disableloader1=true;
       this.disableloader2=true;
    })


    this.category=this.apiservice.getAllCategorie().subscribe(data=>{
      this.tab=data;
        this.tab.categories.forEach(c=>{
          this.pat.push(c);
        });
    })


  }
  gopage(name,type){
    this.navCtrl.navigateForward("/recetbyfilter/"+name+"/"+type);
   // alert(name);
  }

 
}
