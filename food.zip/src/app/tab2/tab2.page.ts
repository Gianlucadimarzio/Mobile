import { ApiServiceService } from './../api-service.service';
import { Component,OnInit } from '@angular/core';
import { IonSlides,NavController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit{
  searchQuery: string = '';
  items: string[];
  tab:any=[];
  tab2:any=[];
  public pat: any=[];
  public mealofday: any=[];
  public category:any=[];

  disableloader1:boolean=false;

  constructor(private apiservice:ApiServiceService,private navCtrl:NavController,private loadingController: LoadingController) {}

  ngOnInit() {
   // this.initdate();
   this.category=this.apiservice.getAllCategorie().subscribe(data=>{
    this.tab=data;
      this.tab.categories.forEach(c=>{
        this.pat.push(c);
      });
      this.disableloader1=true;
  })
  }

  gopage(name,type){
    this.navCtrl.navigateForward("/recetbyfilter/"+name+"/"+type);
   // alert(name);
  }

}
