import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SinglerecetPageRoutingModule } from './singlerecet-routing.module';

import { SinglerecetPage } from './singlerecet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SinglerecetPageRoutingModule
  ],
  declarations: [SinglerecetPage]
})
export class SinglerecetPageModule {}
