import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SinglerecetPage } from './singlerecet.page';

describe('SinglerecetPage', () => {
  let component: SinglerecetPage;
  let fixture: ComponentFixture<SinglerecetPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinglerecetPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SinglerecetPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
