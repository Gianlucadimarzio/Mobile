import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { ApiServiceService } from './../api-service.service';
import {DomSanitizer} from '@angular/platform-browser';
@Component({
  selector: 'app-singlerecet',
  templateUrl: './singlerecet.page.html',
  styleUrls: ['./singlerecet.page.scss'],
})
export class SinglerecetPage implements OnInit {
  searchQuery: string = '';
  items: string[];
  namecat: string;
  tab:any=[];
  tab2:any=[];
  public recet: any=[];
  public meals: any=[];
  public category:any=[];
  disableloader1:boolean=false;
  disableloader2:boolean=false;
  constructor(private active :ActivatedRoute,private apiservice:ApiServiceService,public  sanitizer:DomSanitizer) { }

  ngOnInit() {
    console.log(this.getvideolink("https://www.youtube.com/watch?v=1L1wTXi281k"));
    alert(this.getvideolink("https://www.youtube.com/watch?v=1L1wTXi281k"));
    let id=this.active.snapshot.paramMap.get("id");

    this.category=this.apiservice.getrecet(id).subscribe(data=>{
      this.tab=data;
        this.tab.meals.forEach(c=>{
          c['strYoutube']=this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/'+this.getvideolink(c['strYoutube']));
          this.recet.push(c);
          
        });
        this.disableloader1=true;
    })
  }

  getvideolink(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);

    return (match && match[2].length === 11)
      ? match[2]
      : null;
  }

}
