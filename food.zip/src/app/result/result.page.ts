import { ApiServiceService } from './../api-service.service';
import { Component,OnInit } from '@angular/core';
import { IonSlides,NavController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-result',
  templateUrl: './result.page.html',
  styleUrls: ['./result.page.scss'],
})
export class ResultPage implements OnInit {
  searchQuery: string = '';
  items: string[];
  tab:any=[];
  tab2:any=[];
  testreturn:boolean=false;
  endrchrche:boolean=false;
  
  public pat: any=[];
  public mealofday: any=[];
  public category:any=[];
  constructor(private active :ActivatedRoute,private apiservice:ApiServiceService,private navCtrl:NavController,private loadingController: LoadingController) { }

  ngOnInit() {
    alert(this.active.snapshot.paramMap.get("text"));
    this.category=this.apiservice.getrecherche(this.active.snapshot.paramMap.get("text")).subscribe(data=>{
      this.tab=data;
      alert(this.tab.meals);
      if(this.tab.meals){
        this.testreturn=true;
        this.tab.meals.forEach(c=>{
          this.pat.push(c);
        });
        this.endrchrche=true;
      }else{
        this.testreturn=false;
        this.endrchrche=true;
      }
       
    })
    alert(this.testreturn);
    console.log(this.pat);
    

  }

  gorecet(id){
    this.navCtrl.navigateForward("/singlerecet/"+id);
  }

}
