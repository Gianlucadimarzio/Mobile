import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RecetbyfilterPage } from './recetbyfilter.page';

describe('RecetbyfilterPage', () => {
  let component: RecetbyfilterPage;
  let fixture: ComponentFixture<RecetbyfilterPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecetbyfilterPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RecetbyfilterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
