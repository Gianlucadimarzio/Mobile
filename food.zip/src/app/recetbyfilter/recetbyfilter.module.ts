import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RecetbyfilterPageRoutingModule } from './recetbyfilter-routing.module';

import { RecetbyfilterPage } from './recetbyfilter.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RecetbyfilterPageRoutingModule
  ],
  declarations: [RecetbyfilterPage]
})
export class RecetbyfilterPageModule {}
