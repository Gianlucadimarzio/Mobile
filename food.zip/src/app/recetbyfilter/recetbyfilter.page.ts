import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { ApiServiceService } from './../api-service.service';
import { IonSlides,NavController } from '@ionic/angular';
@Component({
  selector: 'app-recetbyfilter',
  templateUrl: './recetbyfilter.page.html',
  styleUrls: ['./recetbyfilter.page.scss'],
})
export class RecetbyfilterPage implements OnInit {
  searchQuery: string = '';
  items: string[];
  namecat: string;
  tab:any=[];
  tab2:any=[];
  public recet: any=[];
  public meals: any=[];
  public category:any=[];
  disableloader1:boolean=false;
  disableloader2:boolean=false;
  constructor(private active :ActivatedRoute,private apiservice:ApiServiceService,private navCtrl:NavController) { 
    
  }

  ngOnInit() {
    
    let type=this.active.snapshot.paramMap.get("type");
    this.namecat = this.active.snapshot.paramMap.get("name");
    let name = this.active.snapshot.paramMap.get("name");
    this.category=this.apiservice.getAllfoodcategorie(name,type).subscribe(data=>{
      this.tab=data;
        this.tab.meals.forEach(c=>{
          this.recet.push(c);
        });
        this.disableloader1=true;
    })
  //  alert(name);
  }
//https://www.youtube.com/watch?v=oDt8z2lHAHg


gorecet(id){
  this.navCtrl.navigateForward("/singlerecet/"+id);
}
}
