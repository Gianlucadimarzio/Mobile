import { NgModule } from '@angular/core';
import { FlashCardComponent } from './flash-card/flash-card';
import { IonicModule } from 'ionic-angular'

@NgModule({
	declarations: [FlashCardComponent],
	imports: [IonicModule],
	exports: [FlashCardComponent]
})
export class ComponentsModule {}
