import { Login2PageModule } from './../pages/login2/login2.module';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Sign1PageModule } from '../pages/sign1/sign1.module';
import { Sign2PageModule } from '../pages/sign2/sign2.module';
import { Sign3PageModule } from '../pages/sign3/sign3.module';
import { LoginPageModule } from '../pages/login/login.module';
import { Login3PageModule } from '../pages/login3/login3.module';
import { LoginvideobackPageModule } from '../pages/loginvideoback/loginvideoback.module';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    Sign1PageModule,
    Sign2PageModule,
    Sign3PageModule,
    LoginPageModule,
    Login2PageModule,
    Login3PageModule,
    LoginvideobackPageModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
