
import { LoginPage } from './../pages/login/login';
import { Sign1Page } from './../pages/sign1/sign1';
import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { Sign2Page } from '../pages/sign2/sign2';
import { Sign3Page } from '../pages/sign3/sign3';
import { Login2Page } from '../pages/login2/login2';
import { Login3Page } from '../pages/login3/login3';
import { LoginvideobackPage } from '../pages/loginvideoback/loginvideoback';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = LoginPage;

  pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Home', component: HomePage },
      { title: 'SignIn 1', component: Sign1Page },
      { title: 'SignIn 2', component: Sign2Page },
      { title: 'SignIn 3', component: Sign3Page },
      { title: 'Login page', component: LoginPage },
      { title: 'Login2 page', component: Login2Page },
      { title: 'Flip Login page', component: Login3Page },
      { title: 'Video Background', component: LoginvideobackPage}

    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}
