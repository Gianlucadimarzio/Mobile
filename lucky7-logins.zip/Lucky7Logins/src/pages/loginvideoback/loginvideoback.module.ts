import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoginvideobackPage } from './loginvideoback';

@NgModule({
  declarations: [
    LoginvideobackPage,
  ],
  imports: [
    IonicPageModule.forChild(LoginvideobackPage),
  ],
})
export class LoginvideobackPageModule {}
