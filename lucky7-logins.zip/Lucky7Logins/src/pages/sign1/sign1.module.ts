import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sign1Page } from './sign1';

@NgModule({
  declarations: [
    Sign1Page,
  ],
  imports: [
    IonicPageModule.forChild(Sign1Page),
  ],
})
export class Sign1PageModule {}
