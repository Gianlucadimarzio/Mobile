import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sign2Page } from './sign2';

@NgModule({
  declarations: [
    Sign2Page,
  ],
  imports: [
    IonicPageModule.forChild(Sign2Page),
  ],
})
export class Sign2PageModule {}
