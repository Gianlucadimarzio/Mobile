import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Login2Page } from './login2';

@NgModule({
  declarations: [
    Login2Page,
  ],
  imports: [
    IonicPageModule.forChild(Login2Page),
  ],
})
export class Login2PageModule {}
