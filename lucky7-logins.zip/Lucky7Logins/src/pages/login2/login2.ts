import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FlashCardComponent } from '../../components/flash-card/flash-card';

@IonicPage()
@Component({
  selector: 'page-login2',
  templateUrl: 'login2.html',
})
export class Login2Page {
  avatarimage:any;
  signform:any;
  flashCardFlipped: boolean = false;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Login2Page');
    this.avatarimage = 'assets/imgs/avatarleft.png';
    this.signform = "login"
   // this.flashCardFlipped = false;
 //   this.changeAvatar();
  }

  changeAvatar()
  {
    if(this.signform == 'login')
    {
      this.avatarimage = 'assets/imgs/avatarleft.png';
    }

    if(this.signform == 'signup')
    {
      this.avatarimage = 'assets/imgs/avatarright.png';
    }
  }

}
