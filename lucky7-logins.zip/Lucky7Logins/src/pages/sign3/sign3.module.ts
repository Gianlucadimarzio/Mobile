import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Sign3Page } from './sign3';

@NgModule({
  declarations: [
    Sign3Page,
  ],
  imports: [
    IonicPageModule.forChild(Sign3Page),
  ],
})
export class Sign3PageModule {}
