import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  signform:any;
  avatarimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.avatarimage = 'assets/imgs/avatarleft.png';
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
    this.signform = "login"
  }

  onFocus1(event)
  {
    if(event.type == 'focus')
    {
      this.avatarimage = 'assets/imgs/lookdown.png';
    }

    else{
      console.log('dd');
    }
    
  }

  onFocus2(event)
  {
    if(event.type == 'focus')
    {
      this.avatarimage = 'assets/imgs/closeice.png';
    }

    else{
      console.log('dd');
    }
    
  }

}
