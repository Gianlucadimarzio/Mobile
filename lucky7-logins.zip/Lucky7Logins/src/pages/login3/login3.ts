import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the Login3Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login3',
  templateUrl: 'login3.html',
})
export class Login3Page {
  flashCardFlipped: boolean = false;
  

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Login3Page');
  }

  selectAnswer(){
    this.flashCardFlipped = true;
  }

  selectAnswer2(){
    this.flashCardFlipped = false;
  }
}
