import { FlashCardComponent } from '../../components/flash-card/flash-card';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Login3Page } from './login3';

@NgModule({
  declarations: [
    Login3Page,
    FlashCardComponent
  ],
  imports: [
    IonicPageModule.forChild(Login3Page),
  ],
})
export class Login3PageModule {}
