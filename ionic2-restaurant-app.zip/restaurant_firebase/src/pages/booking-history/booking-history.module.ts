import { NgModule } from "@angular/core";
import { IonicPageModule } from "ionic-angular";
import { BookingHistoryPage } from "./booking-history";

@NgModule({
  declarations: [BookingHistoryPage],
  imports: [IonicPageModule.forChild(BookingHistoryPage)]
})
export class BookingHistoryPageModule {}
